import SwiftUI

// MARK: - 纯数据模型（无任何逻辑，绝对安全）
struct MusicItem: Identifiable {
    let id: String
    let title: String
    let coverURL: String
    let uploader: String
    let likeCount: Int
    let commentText: String
    let playURL: String
}

// MARK: - 纯视图（无网络、无异步、无副作用）
struct MusicListView: View {
    let musicList: [MusicItem]
    let onRefresh: () -> Void
    
    var body: some View {
        NavigationStack {
            List(musicList) { music in
                HStack(alignment: .top, spacing: 12) {
                    // 封面图
                    AsyncImage(url: URL(string: music.coverURL)) { phase in
                        if let image = phase.image {
                            image.resizable().scaledToFill()
                        } else {
                            Color.gray.overlay { Image(systemName: "music.note") }
                        }
                    }
                    .frame(width: 60, height: 60)
                    .cornerRadius(8)
                    .clipped()
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(music.title)
                            .font(.headline)
                            .lineLimit(1)
                        
                        Text(music.uploader)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        HStack(spacing: 16) {
                            Label("\(music.likeCount)", systemImage: "heart")
                            Label(music.commentText, systemImage: "message")
                        }
                        .font(.caption)
                        .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("发现音乐")
            .refreshable { onRefresh() }
        }
    }
}

// MARK: - 预览（纯静态数据，绝对安全）
struct MusicListView_Previews: PreviewProvider {
    static var previews: some View {
        MusicListView(
            musicList: [
                MusicItem(
                    id: "401",
                    title: "你走以后（DJ）",
                    coverURL: "https://fireflies.neaol.online/uploads/ee360f3ffb4eac5c146604bba1e2c891.png",
                    uploader: "夏梓璇",
                    likeCount: 0,
                    commentText: "抢前排",
                    playURL: ""
                ),
                MusicItem(
                    id: "409",
                    title: "Watch Me Work",
                    coverURL: "https://fireflies.neaol.online/uploads/823b26be835823939241f7c25a652c01.png",
                    uploader: "夏梓璇",
                    likeCount: 12,
                    commentText: "3",
                    playURL: ""
                )
            ],
            onRefresh: {}
        )
    }
}

// MARK: - 网络层（完全独立，只在真机/模拟器运行时调用）
class MusicAPI {
    static func fetchMusicList() async throws -> [MusicItem] {
        let url = URL(string: "https://fireflies.neaol.online/api/music/music_listw.php")!
        let (data, _) = try await URLSession.shared.data(from: url)
        
        // 手动解析JSON，避免Codable在预览环境的问题
        let json = try JSONSerialization.jsonObject(with: data) as! [String: Any]
        let dataDict = json["data"] as! [String: Any]
        let musicsArray = dataDict["musics"] as! [[String: Any]]
        
        return musicsArray.map { dict in
            MusicItem(
                id: dict["id"] as! String,
                title: dict["title"] as! String,
                coverURL: dict["image"] as! String,
                uploader: dict["uploader"] as! String,
                likeCount: dict["like_count"] as! Int,
                commentText: "\(dict["comment_count"]!)",
                playURL: dict["file_url"] as! String
            )
        }
    }
}

// MARK: - 实际运行时的包装视图（只在真机/模拟器生效）
struct MusicListContainerView: View {
    @State private var musicList: [MusicItem] = []
    @State private var isLoading = false
    
    var body: some View {
        ZStack {
            MusicListView(musicList: musicList, onRefresh: loadData)
            
            if isLoading {
                ProgressView("加载中...")
            }
        }
        .onAppear { loadData() }
    }
    
    private func loadData() {
        isLoading = true
        Task {
            do {
                musicList = try await MusicAPI.fetchMusicList()
            } catch {
                print("加载失败：\(error)")
            }
            isLoading = false
        }
    }
}